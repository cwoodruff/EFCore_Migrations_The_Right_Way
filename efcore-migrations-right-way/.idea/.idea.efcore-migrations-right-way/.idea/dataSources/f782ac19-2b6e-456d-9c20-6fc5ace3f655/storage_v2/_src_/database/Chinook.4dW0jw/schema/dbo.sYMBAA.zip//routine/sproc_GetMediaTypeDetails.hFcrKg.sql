CREATE PROCEDURE [dbo].[sproc_GetMediaTypeDetails]

(
	@MediaTypeId int
)

AS
SELECT CAST((SELECT * FROM [MediaType] WHERE Id = @MediaTypeId FOR JSON PATH) AS VARCHAR(MAX)) AS JSONDATA
go

