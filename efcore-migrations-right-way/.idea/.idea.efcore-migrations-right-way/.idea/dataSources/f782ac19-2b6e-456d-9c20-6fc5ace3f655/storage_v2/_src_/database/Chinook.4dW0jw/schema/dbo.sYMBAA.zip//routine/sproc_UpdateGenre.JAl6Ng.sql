CREATE PROCEDURE [dbo].[sproc_UpdateGenre]
(
	@GenreId int,
	@Name nvarchar (MAX)
)

AS
UPDATE [Genre] 
SET 
Name = @Name
WHERE Id = @GenreId


/*DROP PROC dbo.sproc_UpdateGenre*/
go

