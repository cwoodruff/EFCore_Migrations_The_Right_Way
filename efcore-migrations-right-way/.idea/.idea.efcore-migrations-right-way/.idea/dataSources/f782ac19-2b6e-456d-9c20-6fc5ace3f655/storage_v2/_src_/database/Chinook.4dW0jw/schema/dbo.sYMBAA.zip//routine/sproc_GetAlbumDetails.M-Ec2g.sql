CREATE PROCEDURE [dbo].[sproc_GetAlbumDetails]

(
	@AlbumId int
)
AS
SELECT CAST((SELECT * FROM [Album] WHERE Id = @AlbumId  FOR JSON PATH) AS VARCHAR(MAX)) AS JSONDATA


/*DROP PROC dbo.sproc_GetAlbumDetails*/
go

