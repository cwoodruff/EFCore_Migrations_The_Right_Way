CREATE PROCEDURE [dbo].[sproc_UpdateMediaType]
(
	@MediaTypeId int,
	@Name nvarchar (MAX)
)

AS
UPDATE [MediaType] 
SET 
Name = @Name
WHERE Id = @MediaTypeId


/*DROP PROC dbo.sproc_UpdateMediaType*/
go

