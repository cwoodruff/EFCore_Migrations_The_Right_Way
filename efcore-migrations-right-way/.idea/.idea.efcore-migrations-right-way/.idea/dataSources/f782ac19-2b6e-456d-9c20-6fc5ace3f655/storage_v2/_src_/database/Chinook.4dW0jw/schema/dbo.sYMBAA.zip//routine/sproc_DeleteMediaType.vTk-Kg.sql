CREATE PROCEDURE [dbo].[sproc_DeleteMediaType]

(
	@MediaTypeId int
)

AS
DELETE FROM [MediaType]
WHERE Id = @MediaTypeId


/*DROP PROC dbo.sproc_DeleteMediaType*/
go

