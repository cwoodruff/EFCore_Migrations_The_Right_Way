CREATE PROCEDURE [dbo].[sproc_DeleteInvoiceLine]

(
	@InvoiceLineId int
)

AS
DELETE FROM [InvoiceLine]
WHERE Id = @InvoiceLineId


/*DROP PROC dbo.sproc_DeleteInvoiceLine*/
go

