CREATE PROCEDURE [dbo].[sproc_DeleteTrack]

(
	@TrackId int
)

AS
DELETE FROM [Track]
WHERE Id = @TrackId


/*DROP PROC dbo.sproc_DeleteTrack*/
go

