CREATE PROCEDURE [dbo].[sproc_DeleteGenre]

(
	@GenreId int
)

AS
DELETE FROM [Genre]
WHERE Id = @GenreId


/*DROP PROC dbo.sproc_DeleteGenre*/
go

