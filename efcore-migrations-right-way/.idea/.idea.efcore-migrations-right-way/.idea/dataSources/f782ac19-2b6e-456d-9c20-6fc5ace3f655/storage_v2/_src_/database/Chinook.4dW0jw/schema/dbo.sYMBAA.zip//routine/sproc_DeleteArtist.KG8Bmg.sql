CREATE PROCEDURE [dbo].[sproc_DeleteArtist]

(
	@ArtistId int
)

AS
DELETE FROM [Artist]
WHERE Id = @ArtistId


/*DROP PROC dbo.sproc_DeleteArtist*/
go

