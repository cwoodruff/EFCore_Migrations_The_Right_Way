CREATE PROCEDURE [dbo].[sproc_DeleteAlbum]

(
	@AlbumId int
)

AS
DELETE FROM [Album]
WHERE Id = @AlbumId


/*DROP PROC dbo.sproc_DeleteAlbum*/
go

