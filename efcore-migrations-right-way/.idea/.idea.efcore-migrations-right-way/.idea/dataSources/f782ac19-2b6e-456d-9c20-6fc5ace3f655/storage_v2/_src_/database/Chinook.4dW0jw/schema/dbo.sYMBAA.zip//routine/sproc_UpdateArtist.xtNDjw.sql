CREATE PROCEDURE [dbo].[sproc_UpdateArtist]
(
	@ArtistId int,
	@Name nvarchar (MAX)
)

AS
UPDATE [Artist] 
SET 
Name = @Name
WHERE Id = @ArtistId


/*DROP PROC dbo.sproc_UpdateArtist*/
go

