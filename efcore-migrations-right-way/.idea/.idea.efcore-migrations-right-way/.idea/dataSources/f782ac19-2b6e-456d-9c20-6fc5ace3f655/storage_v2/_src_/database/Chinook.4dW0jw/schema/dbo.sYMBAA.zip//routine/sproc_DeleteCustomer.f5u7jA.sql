CREATE PROCEDURE [dbo].[sproc_DeleteCustomer]

(
	@CustomerId int
)

AS
DELETE FROM [Customer]
WHERE Id = @CustomerId


/*DROP PROC dbo.sproc_DeleteCustomer*/
go

