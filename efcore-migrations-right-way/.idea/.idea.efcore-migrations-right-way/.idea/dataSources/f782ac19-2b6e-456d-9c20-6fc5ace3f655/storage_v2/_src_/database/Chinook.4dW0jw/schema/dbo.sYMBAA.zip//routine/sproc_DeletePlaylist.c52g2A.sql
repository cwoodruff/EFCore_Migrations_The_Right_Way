CREATE PROCEDURE [dbo].[sproc_DeletePlaylist]

(
	@PlaylistId int
)

AS
DELETE FROM [Playlist]
WHERE Id = @PlaylistId


/*DROP PROC dbo.sproc_DeletePlaylist*/
go

