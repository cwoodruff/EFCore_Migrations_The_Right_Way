CREATE PROCEDURE [dbo].[sproc_DeleteInvoice]

(
	@InvoiceId int
)

AS
DELETE FROM [Invoice]
WHERE Id = @InvoiceId


/*DROP PROC dbo.sproc_DeleteInvoice*/
go

