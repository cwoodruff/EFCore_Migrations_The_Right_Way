CREATE PROCEDURE [dbo].[sproc_DeleteEmployee]

(
	@EmployeeId int
)

AS
DELETE FROM [Employee]
WHERE Id = @EmployeeId


/*DROP PROC dbo.sproc_DeleteEmployee*/
go

